package com.siva.juiceordermanagement;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper myDb;
    EditText editJuiceNo, editJuiceName, editQuantity, editPrice;
    Button btnAdd, btnViewAll, btnUpdate, btnDelete;
    TextView textViewOrders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDb = new DatabaseHelper(this);

        editJuiceNo = findViewById(R.id.editTextJuiceNo);
        editJuiceName = findViewById(R.id.editTextJuiceName);
        editQuantity = findViewById(R.id.editTextQuantity);
        editPrice = findViewById(R.id.editTextPrice);
        btnAdd = findViewById(R.id.buttonAdd);
        btnViewAll = findViewById(R.id.buttonViewAll);
        btnUpdate = findViewById(R.id.buttonUpdate);
        btnDelete = findViewById(R.id.buttonDelete);
        textViewOrders = findViewById(R.id.textViewOrders);

        addData();
        viewAll();
        updateData();
        deleteData();
    }

    public void addData() {
        btnAdd.setOnClickListener(v -> {
            boolean isInserted = myDb.insertData(
                    editJuiceName.getText().toString(),
                    Integer.parseInt(editQuantity.getText().toString()),
                    Double.parseDouble(editPrice.getText().toString())
            );
            if (isInserted)
                Toast.makeText(MainActivity.this, "Data Inserted", Toast.LENGTH_LONG).show();
            else
                Toast.makeText(MainActivity.this, "Data Not Inserted", Toast.LENGTH_LONG).show();
        });
    }

    public void viewAll() {
        btnViewAll.setOnClickListener(v -> {
            Cursor res = myDb.getAllData();
            if (res.getCount() == 0) {
                showMessage("Error", "Nothing found");
                return;
            }

            StringBuilder buffer = new StringBuilder();
            while (res.moveToNext()) {
                buffer.append("Juice No :").append(res.getString(0)).append("\n");
                buffer.append("Juice Name :").append(res.getString(1)).append("\n");
                buffer.append("Quantity :").append(res.getString(2)).append("\n");
                buffer.append("Price :").append(res.getString(3)).append("\n\n");
            }

            textViewOrders.setText(buffer.toString());
        });
    }

    public void updateData() {
        btnUpdate.setOnClickListener(v -> {
            boolean isUpdate = myDb.updateData(
                    Integer.parseInt(editJuiceNo.getText().toString()),
                    editJuiceName.getText().toString(),
                    Integer.parseInt(editQuantity.getText().toString()),
                    Double.parseDouble(editPrice.getText().toString())
            );
            if (isUpdate)
                Toast.makeText(MainActivity.this, "Data Updated", Toast.LENGTH_LONG).show();
            else
                Toast.makeText(MainActivity.this, "Data Not Updated", Toast.LENGTH_LONG).show();
        });
    }

    public void deleteData() {
        btnDelete.setOnClickListener(v -> {
            int deletedRows = myDb.deleteData(Integer.parseInt(editJuiceNo.getText().toString()));
            if (deletedRows > 0)
                Toast.makeText(MainActivity.this, "Data Deleted", Toast.LENGTH_LONG).show();
            else
                Toast.makeText(MainActivity.this, "Data Not Deleted", Toast.LENGTH_LONG).show();
        });
    }

    public void showMessage(String title, String Message) {
        Toast.makeText(this, title + " - " + Message, Toast.LENGTH_SHORT).show();
    }
}
